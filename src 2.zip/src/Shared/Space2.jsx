import React, { useEffect } from "react";

export const ThreeComponent = () => {
    useEffect(() => {
        const script = document.createElement("script");
        script.src = "/ThreeScene.js";
        script.async = true;
        document.body.appendChild(script);

        return () => {
            document.body.removeChild(script);
        };
    }, []);

    return <div id="canvas_container" style={{ width: "100%", height: "100vh" }} />;
};

